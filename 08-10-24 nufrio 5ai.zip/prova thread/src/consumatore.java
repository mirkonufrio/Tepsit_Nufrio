class Consumatore extends Thread {
    private Buffer buffer;

    public Consumatore(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            int pari = 0, dispari = 0;
            while (true) {
                int value = buffer.get();
                if (value % 2 == 0) {
                    pari++;
                } else {
                    dispari++;
                }
                System.out.println("Letto: " + value + ", Pari: " + pari + ", Dispari: " + dispari);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}