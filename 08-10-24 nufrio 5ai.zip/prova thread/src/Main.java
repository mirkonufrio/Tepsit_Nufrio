
public class Main {
    public static void main(String[] args) {
        int bufferSize = 10;
        Buffer buffer = new Buffer(bufferSize);
        Produttore produttore = new Produttore(buffer);
        Consumatore consumatore = new Consumatore(buffer);
        produttore.start();
        consumatore.start();
    }
}
