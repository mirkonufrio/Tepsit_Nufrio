import java.util.Random;

class Produttore extends Thread {
    private Buffer buffer;
    private Random random = new Random();

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            while (true) {
                int value = random.nextInt(1024);
                int sleepTime = 100 + random.nextInt(901);
                Thread.sleep(sleepTime);
                buffer.put(value);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
