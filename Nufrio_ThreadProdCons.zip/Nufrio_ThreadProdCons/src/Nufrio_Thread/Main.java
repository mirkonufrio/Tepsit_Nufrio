package Nufrio_Thread;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		//variabile per il numero dei thread
		int T;
		//vsriabile per il numero che ciascun thread deve contare
		int N;
		Scanner scanner = new Scanner (System.in);
		
		
		//numero di thread da creare
		System.out.println("Quanti Thread desideri creare?");
		T = scanner.nextInt();
		
		//numero che ogni thread deve contare
		System.out.println("Qual'è il valore che deve contare ogni thread?");
		N = scanner.nextInt();
		
		//creo un Array per i Thread creati
		Thread[] threads = new Thread[T];
		
		//creo T thread 
		for (int i = 0; i < threads.length; i++) {
		}
		}
		}
			

