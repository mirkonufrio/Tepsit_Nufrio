package Nufrio_Thread;

import java.util.Random;

public class Produttore extends Thread implements Runnable{
	
	private Random random = new Random();

}
