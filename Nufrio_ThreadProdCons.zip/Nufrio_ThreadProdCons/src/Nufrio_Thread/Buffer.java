package Nufrio_Thread;

import java.util.LinkedList;

public class Buffer {
	
	LinkedList<Integer> buffer = new LinkedList<Integer>();
	

}
