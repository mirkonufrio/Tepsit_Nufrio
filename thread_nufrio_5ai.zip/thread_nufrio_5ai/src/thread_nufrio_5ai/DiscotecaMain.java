package thread_nufrio_5ai;

import java.util.Random;

public class DiscotecaMain {
	
	public static void main(String[] args) {
		int numPersone=10;
		Conta cont=new Conta();
		
		for(int i=0;i<numPersone;i++) {
			Thread persona=new Thread(new Persona());
			persona.start();
		}
		while(true) {
				try {
					Thread.sleep(1000);
					System.out.println("Persone in discoteca: "+cont.getPersone());
				}catch(InterruptedException e){
					e.printStackTrace();
				
				}
		}	
	}

}

    
