package thread_nufrio_5ai;

public class Conta {
	
	private static int numPersone=0;

	public synchronized void entra() {
		numPersone++;
		System.out.println(Thread.currentThread().getName()+" è entrato in discoteca");
	}

	public synchronized void esci() {
		numPersone--;
		System.out.println(Thread.currentThread().getName()+" è uscito dalla discoteca");
	}

	public int getPersone() {
		return numPersone;
	}
}

    