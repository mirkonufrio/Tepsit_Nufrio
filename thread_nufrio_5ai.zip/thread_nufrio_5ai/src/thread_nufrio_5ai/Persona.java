package thread_nufrio_5ai;

import java.util.Random;

public class Persona implements Runnable{
	Conta cont =new Conta();
	Random rand =new Random();
	
	public void run() {
		while(true) {
			try {
				cont.entra();
				Thread.sleep(rand.nextInt(5000) + 2000);
				
				cont.esci();
				Thread.sleep(rand.nextInt(5000) + 2000);
			}catch (InterruptedException e) {
				e.printStackTrace();
            }
		}
	}
}

    
